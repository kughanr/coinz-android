# coinz

University project where I developed an Android application, a game where coins are spawned on a map and players can walk around in real life and collect, deposit and message coins. 
<br/><br/>
Technology used: Kotlin, XML and Gradle for main development, Firebase for user management and for databases, MapBox to build the maps and Java for tests.
